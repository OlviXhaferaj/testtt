

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add Historic Event</title>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
</head>

<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add historic event')); ?></div>
                    <div class="container mt-2">
                        <div class="row">
                            <div class="col-lg-12 margin-tb">
                                <div class="pull-left mb-2">
                                    <h2>Historic event</h2>
                                </div>
                            </div>
                        </div>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success mb-1 mt-1">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <form id="live_form" action="<?php echo e(route('events.store')); ?>" method="POST" enctype="multipart/form-data" class="pb-3">
                            <?php echo csrf_field(); ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- creating events -->
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="d-flex gap-3 w-100">
                                
                                <div class="d-flex flex-column w-50">
                                    <div class="row mb-3 ">
                                        <label for="name" class="col-form-label" ><?php echo e(__('Name:*')); ?></label>
                                        <div class="col-md-6 w-100">
                                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="image" class="col-form-label"><?php echo e(__('Image:')); ?></label>
                                        <div class="col-md-6 w-100">
                                            <input id="image" type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> w-100" name="image" value="<?php echo e(old('image')); ?>" required autocomplete="image">
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex flex-column w-50">
                                    <div class="row mb-3">
                                        <label for="eventType" class="col-form-label"><?php echo e(__('Event Type:*')); ?></label>
                                        <div class="col-md-6 w-100">
                                            <select id="eventType" 
                                            type="text" 
                                            class="form-control <?php $__errorArgs = ['eventType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="eventType" 
                                            value="<?php echo e(old('eventType')); ?>" 
                                            required 
                                            autocomplete="eventType" 
                                            selected="Birth"
                                            >
                                                <option value="Death">Death</option>
                                                <option value="Birth" selected="selected">Birth</option>
                                                <option value="Birth">Other</option>
                                            </select>
                                            <?php $__errorArgs = ['eventType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <label for="epoce" class="col-form-label"><?php echo e(__('Epoce:*')); ?></label>
                                        <div class="col-md-6 w-100">
                                            <select id="epoce" type="text" class="form-control <?php $__errorArgs = ['epoce'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="epoce" value="<?php echo e(old('epoce')); ?>" required autocomplete="epoce" selected="AC">
                                                <option value="BC">B.C.</option>
                                                <option value="AC" selected="selected">A.C.</option>
                                            </select>
                                            <?php $__errorArgs = ['epoce'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>                                
                            </div>
                            <hr/>
                                
                            <div>
                                <div>
                                    <div class="form-group">
                                        <label valueee={is_value} class="control-label">Select 'yes' if you know the exact date of the event, else select 'no'.</label>
                                    <div>
                                    <div class="radio">
                                        <label class="radio">
                                        <input name="rating" type="radio" value="Yes"/>
                                        Yes
                                        </label>
                                    </div>

                                    <div class="radio">
                                        <label class="radio">
                                        <input name="rating" type="radio" value="No"/>
                                        No
                                        </label>
                                    </div>
                                </div>

                                <div class="form-group d-none d-flex gap-2 " >
                                    <div class="row mb-3" id="feedback_no" name="feedback_no">
                                        <label for="year" class="col-form-label"><?php echo e(__('Year:*')); ?></label>
                                        <div class="col-md-6 w-100">
                                            <input id="year" type="number" class="form-control <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="year" value="<?php echo e(old('year')); ?>" autocomplete="year">
                                            <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                
                                    <div class="row mb-3 " id="feedback_no" name="feedback_no">
                                        <label for="month" class="col-form-label"><?php echo e(__('Month:*')); ?></label>
                                        <div class="col-md-6 w-100">
                                            <input id="month" type="number" class="form-control <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="month" value="<?php echo e(old('month')); ?>" autocomplete="month"  min="1" max="12">
                                            <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3" id="feedback_no" name="feedback_no">
                                        <label for="day" class="col-form-label"><?php echo e(__('Day:*')); ?></label>
                                        <div class="col-md-6 w-100">
                                            <input type="number" id="day" class="form-control <?php $__errorArgs = ['day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="day" value="<?php echo e(old('day')); ?>" autocomplete="day"  min="1" max="31"/>

                                            <?php $__errorArgs = ['day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group d-none w-50">
                                    <div class="row mb-3" id="feedback_yes" name="feedback_yes">
                                        <label for="event_trigger_date" class="col-form-label"><?php echo e(__('Event Date:')); ?></label>
                                        <div class="col-md-6 w-100">
                                            <input id="datepicker" type="text" class="form-control <?php $__errorArgs = ['event_trigger_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> w-100" name="event_trigger_date" value="<?php echo e(old('event_trigger_date')); ?>" autocomplete="event_trigger_date">

                                            <?php $__errorArgs = ['event_trigger_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <div class="row mb-3">
                                    <label for="description" class="col-form-label"><?php echo e(__('Description:*')); ?></label>
                                    <div class="col-md-6 w-100">
                                        <textarea id="description" type="text" class="textarea <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('description')); ?>" autocomplete="description" name="description" cols="22" rows="5"></textarea>
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row mb-0 mt-4 d-flex">
                                    <div class="d-flex gap-1">
                                        <div class="col-md-6 ">
                                            <button type="submit" class="btn btn-primary ml-3">Submit</button>
                                        </div>
                                        <div class="pull-right">
                                            <a class="btn btn-dark" href="<?php echo e(route('events.index')); ?>" enctype="multipart/form-data">
                                                Back</a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
    <script>
    $(document).ready( function() {
        $( "#datepicker" ).datepicker({
            dateFormat:"yy-mm-dd"
        });
    } );
    </script>
<script>
    $( document ).ready(function() { //wait until body loads

        //Inputs that determine what fields to show
        var rating = $('#live_form input:radio[name=rating]');
        var testimonial=$('#live_form input:radio[name=testimonial]');				

        //Wrappers for all fields
        var yes = $('#live_form div[name="feedback_yes"]').parent();
        var no = $('#live_form div[name="feedback_no"]').parent();
        var great = $('#live_form textarea[name="feedback_great"]').parent();
        var testimonial_parent = $('#live_form #div_testimonial');
        var thanks_anyway  = $('#live_form #thanks_anyway');
        var all=yes.add(no).add(great).add(testimonial_parent).add(thanks_anyway); //shortcut for all wrapper elements

        rating.change(function(){ //when the rating changes
            var value=this.value;	
            console.log(rating, 'this is rating');					

            var is_value=true;
            console.log(value);					
            all.addClass('d-none'); //hide everything and reveal as needed
            
            if (value == 'Yes' ){
                is_value = true;
                yes.removeClass('d-none'); //show feedback_yes	

                document.getElementById("year").value='';
                document.getElementById("month").value='';
                document.getElementById("day").value='';
            }
            else if (value == 'No'){
                is_value = false;
                no.removeClass('d-none'); //show feedback_no	
                document.getElementById("datepicker").value='';
            }		
            console.log(is_value);
        });	
    });
    </script>
        <!-- TinyMcs script -->
        <script src="<?php echo e(asset('js/tinymce/tinymce.js')); ?>"></script>

    <script>
        tinymce.init({
            selector: '#description', 
            plugins: [ "image", "code", "table", "link", "media", "codesample"],
            toolbar: 'undo redo | blocks| bold italic | bullist numlist checklist | code | table'
        });
    </script>


</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\laravel\larainfo\resources\views/events/create.blade.php ENDPATH**/ ?>